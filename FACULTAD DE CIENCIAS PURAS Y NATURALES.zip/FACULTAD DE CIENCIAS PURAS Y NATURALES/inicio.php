<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FACULTAD DE CIENCIAS PURAS Y NATURALES</title>
    <link rel="stylesheet" href="./CSS/inicio.css">
</head>
<body>
    <header class="cabecera">
        <div  class="logotipo">
                <img class="imglogo" src="./IMAGENES/EscudoFCPN.png"/>
        </div>
        <div class="titulo">
                <h1>Universidad Mayor de San Andres</h1>
                <h2>Facultad de Ciencias Puras y Naturales</h2>
        </div>
    </header>
    <section class="seccion">
        <article class="carreras">
            <h2 class="carreras_h2">NUESTRAS CARRERAS</h2>
        </article>
        <div class="informatica">
            <a class="informatica_a" href="./CARRERA DE INFORMATICA/informatica.php">INFORMATICA</a>
            <a class="informatica_img_a" href="./CARRERA DE INFORMATICA/informatica.php"><img class="informatica_img" src="./IMAGENES/logo_ingo.png" alt=""></a>
        </div>
        <div class="estadistica">
            <a class="estadistica_a" href="./CARRERA DE ESTADISTICA/estadistica.php">ESTADISTICA</a>
            <a class="estadistica_img_a" href="./CARRERA DE ESTADISTICA/estadistica.php"><img class="estadistica_img" src="./IMAGENES/estadistica.png" alt="" ></a>
        </div>
        <div class="matematica">
            <a class="matematica_a" href="./CARRERA DE MATEMATICA/matematica.php">MATEMATICA</a>
            <a class="matematica_img_a" href="./CARRERA DE MATEMATICA/matematica.php"><img class="matematica_img" src="./IMAGENES/logocarrera.png" alt=""></a>
        </div>
    </section>

</body>
</html>