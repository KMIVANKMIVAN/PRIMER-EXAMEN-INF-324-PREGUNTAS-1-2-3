<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FACULTAD DE CIENCIAS PURAS Y NATURALES</title>
	<link rel="stylesheet" href="./css/notas.css">
	<link rel="stylesheet" href="./css/inicio.css">
</head>
<body>
    <?php
    include('mostrar_notas.php');
    $sql="select nota1,nota2,nota3,notafinal, departamento, if(departamento = '1', 'LA PAZ', if(departamento = '2','COCHABAMBA','SANTA CRUZ')) as CIUDAD from persona as per INNER JOIN nota as nota ON per.CI_persona=nota.CI_persona";
    $resultado=mysqli_query($conexion, $sql);
    ?>
	<header class="cabecera">
        <div  class="logotipo">
                <img class="imglogo" src="./IMAGENES/EscudoFCPN.png"/>
        </div>
        <div class="titulo">
                <h1>Universidad Mayor de San Andres</h1>
                <h2>Facultad de Ciencias Puras y Naturales</h2>
        </div>
        <div class="menu">
			<ul>
				<li>
				<a href="../inicio.php">INICIO</a>
				</li>
				<li>
				<a href="./informatica.php">INFORMATICA</a>
				</li>
				<li>
				<a href="../CARRERA DE ESTADISTICA/estadistica.php">ESTADISTICA</a>
				</li>
                <li>
				<a href="../CARRERA DE MATEMATICA/matematica.php">MATEMATICA</a>
				</li>
			<ul>
		</div>
    </header>
    <table border="1">
    <thead>
		<tr>
			<th>NOTA 1</th>
			<th>NOTA 2</th>
			<th>NOTA 3</th>
			<th>NOTA FINAL</th>
			<th>DEPARTAMENTO</th>
			<th>CIUDAD</th>
		</tr>
		</thead>
	<tbody>
		<?php
			while($fila=mysqli_fetch_array($resultado)) {
				echo "<tr>";
				echo "<td>".$fila['nota1']."</td>";
                echo "<td>".$fila["nota2"]."</td>";
				echo "<td>$fila[nota3]</td>";
				echo "<td>".$fila['notafinal']."</td>";
				echo "<td>".$fila['departamento']."</td>";
				echo "<td>".$fila['CIUDAD']."</td>";
				echo "</tr>";
			}
		?>
		</tbody>
	</table>
	<center>
		<h1>PROMEDIOS</h1>
	</center>
	<section>
		<form method="POST" action="">
			<center>
				<input type="submit" value="Promedio nota 1 LA PAZ" class="btn btn-info" name="btn1">
				<input type="submit" value="Promedio nota 1 COCHABAMBA" class="btn btn-info" name="btn11">
				<input type="submit" value="Promedio nota 1 SANTA CRUZ" class="btn btn-info" name="btn111">
				<br>
				<input type="submit" value="Promedio nota 2 LA PAZ" class="btn btn-info" name="btn2">
				<input type="submit" value="Promedio nota 2 COCHABAMBA" class="btn btn-info" name="btn22">
				<input type="submit" value="Promedio nota 2 SANTA CRUZ" class="btn btn-info" name="btn222">
				<br>
				<input type="submit" value="Promedio nota 3 LA PAZ" class="btn btn-info" name="btn3">
				<input type="submit" value="Promedio nota 3 COCHABAMBA" class="btn btn-info" name="btn33">
				<input type="submit" value="Promedio nota 3 SANTA CRUZ" class="btn btn-info" name="btn333">
				<br>
				<input type="submit" value="Promedio nota Final LA PAZ" class="btn btn-info" name="btn4">
				<input type="submit" value="Promedio nota Final COCHABAMBA" class="btn btn-info" name="btn44">
				<input type="submit" value="Promedio nota Final SANTA CRUZ" class="btn btn-info" name="btn444">
				<br>
			</center>
		</form>
		<center>
		<h1>PROMEDIOS DE SU DEPARTAMENTO</h1>

		<?php

			if (isset($_POST['btn1'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota1) AS PROMEDIO_NOTA_1, departamento AS LA_PAZ from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='1'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 1 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 1: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_1']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["LA_PAZ"]."</td>";
				echo " -> LA PAZ";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);

			}
			if (isset($_POST['btn11'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota1) AS PROMEDIO_NOTA_1, departamento AS COCHABAMBA from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='2'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 2 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 1: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_1']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["COCHABAMBA"]."</td>";
				echo " -> COCHABAMBA";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
			if (isset($_POST['btn111'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota1) AS PROMEDIO_NOTA_1, departamento AS SANTA_CRUZ from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='3'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 3 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 1: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_1']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["SANTA_CRUZ"]."</td>";
				echo " -> SANTA CRUZ";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
			if (isset($_POST['btn4'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(notafinal) AS PROMEDIO_NOTA_FINAL, departamento AS LA_PAZ from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='1'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA FINAL ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA FINAL: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_FINAL']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["LA_PAZ"]."</td>";
				echo " -> LA PAZ";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
			if (isset($_POST['btn2'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota1) AS PROMEDIO_NOTA_2, departamento AS LA_PAZ from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='1'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 1 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 2: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_2']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["LA_PAZ"]."</td>";
				echo " -> LA PAZ";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);

			}
			if (isset($_POST['btn22'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota1) AS PROMEDIO_NOTA_2, departamento AS COCHABAMBA from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='2'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 2 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 2: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_2']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["COCHABAMBA"]."</td>";
				echo " -> COCHABAMBA";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
			if (isset($_POST['btn222'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota2) AS PROMEDIO_NOTA_2, departamento AS SANTA_CRUZ from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='3'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 3 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 2: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_2']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["SANTA_CRUZ"]."</td>";
				echo " -> SANTA CRUZ";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
			if (isset($_POST['btn44'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(notafinal) AS PROMEDIO_NOTA_FINAL, departamento AS COCHABAMBA from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='2'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA FINAL ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA FINAL: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_FINAL']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["COCHABAMBA"]."</td>";
				echo " -> COCHABAMBA";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
			if (isset($_POST['btn3'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota3) AS PROMEDIO_NOTA_3, departamento AS LA_PAZ from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='1'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 1 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 3: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_3']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["LA_PAZ"]."</td>";
				echo " -> LA PAZ";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);

			}
			if (isset($_POST['btn33'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota3) AS PROMEDIO_NOTA_3, departamento AS COCHABAMBA from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='2'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 2 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 3: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_3']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["COCHABAMBA"]."</td>";
				echo " -> COCHABAMBA";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
			if (isset($_POST['btn333'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(nota3) AS PROMEDIO_NOTA_3, departamento AS SANTA_CRUZ from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='3'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA 3 ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA 3: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_3']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["SANTA_CRUZ"]."</td>";
				echo " -> SANTA CRUZ";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
			if (isset($_POST['btn444'])) {
				include('mostrar_notas.php');
				$resultadonota1 = mysqli_query($conexion,"select AVG(notafinal) AS PROMEDIO_NOTA_FINAL, departamento AS SANTA_CRUZ from persona INNER JOIN nota WHERE persona.CI_persona=nota.CI_persona AND persona.departamento='3'");
				$consulta = mysqli_fetch_array($resultadonota1);
				//echo "EL RPOMEDIO DE LA NOTA FINAL ES: ";
				echo "<tr>";
				echo "PROMEDIO DE NOTA FINAL: ";
				echo "<td>".$consulta['PROMEDIO_NOTA_FINAL']."</td>";
				echo "<br>";
				echo "DEPARTAMENTO: ";
				echo "<td>".$consulta["SANTA_CRUZ"]."</td>";
				echo " -> SANTA CRUZ";
				echo "</tr>";
				//echo "<td>".$consulta["0"]."</td>";
				//var_dump($consulta);
			}
		?>
		</center>
		
	</section>
</body>
</html>