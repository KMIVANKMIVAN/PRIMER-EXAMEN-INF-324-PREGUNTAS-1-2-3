<?php

    $dbhost = "localhost";
    $dbuser = "ivan";
    $dbpass = "8433318";
    $dbname = "mibdivan";

    $conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
    //$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    if (!$conn)
    {
        die("NO HAY CONEXION: ".mysqli_connect_error());
    }

    $CI = $_POST["txtci"];
    $Usuario = $_POST["txtusuario"];
    $Password = $_POST["txtpassword"];

    $query = mysqli_query($conn, "SELECT * FROM usuario where ci='".$CI."' and Usuario='".$Usuario."' and Password='".$Password."'");
    $nr =  mysqli_num_rows($query);

    if ($nr == 1) {
        //echo "Bien Venido: " .$Usuario;
        header("Location: http://localhost/PRIMER%20EXAMEN/FACULTAD%20DE%20CIENCIAS%20PURAS%20Y%20NATURALES/CARRERA%20DE%20INFORMATICA/media.php");

    }
    else if ($nr == 0) {
        echo "No Es Usuario";
    }
?>