<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>NOTAS</title>
	<link rel="stylesheet" href="./css/notas.css">
</head>
<body>
<?php
include('mostrar_notas.php');
$sql="select CI_nota, Sigla, nota1, nota2, nota3, notafinal, CI_persona from nota";
$resultado=mysqli_query($conexion, $sql);
?>
<table border="1">
    <thead>
		<tr>
			<th>CI NOTA</th>
			<th>MATERIA</th>
			<th>NOTA 1</th>
			<th>NOTA 2</th>
			<th>NOTA 3</th>
			<th>NOTA FINAL</th>
			<th>CI ESTUDIANTE</th>
		</tr>
		</thead>
	<tbody>
		<?php
			while($fila=mysqli_fetch_array($resultado)) {
				echo "<tr>";
				echo "<td>".$fila["CI_nota"]."</td>";
				echo "<td>$fila[Sigla]</td>";
				echo "<td>".$fila['nota1']."</td>";
                echo "<td>".$fila["nota2"]."</td>";
				echo "<td>$fila[nota3]</td>";
				echo "<td>".$fila['notafinal']."</td>";
                //echo "<td>".$fila["CI_docente"]."</td>";
				echo "<td>$fila[CI_persona]</td>";
				//echo "<td>".$fila['CI_materia']."</td>";
				echo "</tr>";
			}
		?>
	</tbody>
</table>
</body>
</html>
