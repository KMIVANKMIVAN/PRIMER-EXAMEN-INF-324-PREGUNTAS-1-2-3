<?php
    $conexion=mysqli_connect('localhost','ivan','8433318','mibdivan');
	mysqli_select_db($conexion,"mibdivan");
?>