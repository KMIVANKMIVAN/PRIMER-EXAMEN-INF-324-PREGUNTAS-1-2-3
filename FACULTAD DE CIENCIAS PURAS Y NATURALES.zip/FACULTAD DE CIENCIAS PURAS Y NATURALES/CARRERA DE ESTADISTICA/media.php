<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FACULTAD DE CIENCIAS PURAS Y NATURALES</title>
</head>
<body>
    <?php
    include('mostrar_notas.php');
    $sql="select nota1, nota2, nota3, notafinal from nota";
    $resultado=mysqli_query($conexion, $sql);
    ?>
    <table border="1">
    <thead>
		<tr>
			<th>NOTA 1</th>
			<th>NOTA 2</th>
			<th>NOTA 3</th>
			<th>NOTA FINAL</th>
		</tr>
		</thead>
	<tbody>
		<?php
			while($fila=mysqli_fetch_array($resultado)) {
				echo "<tr>";
				echo "<td>".$fila['nota1']."</td>";
                echo "<td>".$fila["nota2"]."</td>";
				echo "<td>$fila[nota3]</td>";
				echo "<td>".$fila['notafinal']."</td>";
				echo "</tr>";
			}
		?>
	</tbody>
</table>
</body>
</html>