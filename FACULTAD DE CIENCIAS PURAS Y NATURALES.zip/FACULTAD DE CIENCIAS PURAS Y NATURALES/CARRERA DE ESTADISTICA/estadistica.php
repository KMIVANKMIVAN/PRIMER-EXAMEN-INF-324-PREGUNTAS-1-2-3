<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FACULTAD DE CIENCIAS PURAS Y NATURALES</title>
    <link rel="stylesheet" href="./CSS/inicio.css">
    <link rel="stylesheet" href="./CSS/login.css">
</head>
<body>
    <header class="cabecera">
        <div  class="logotipo">
                <img class="imglogo" src="./IMAGENES/EscudoFCPN.png"/>
        </div>
        <div class="titulo">
                <h1>Universidad Mayor de San Andres</h1>
                <h2>Facultad de Ciencias Puras y Naturales</h2>
        </div>
        <div class="menu">
			<ul>
				<li>
				<a href="../inicio.php">INICIO</a>
				</li>
				<li>
				<a href="../CARRERA DE INFORMATICA/informatica.php">INFORMATICA</a>
				</li>
				<li>
				<a href="./estadistica.php">ESTADISTICA</a>
				</li>
                <li>
				<a href="../CARRERA DE MATEMATICA/matematica.php">MATEMATICA</a>
				</li>
			<ul>
		</div>
    </header>
    <section class="seccion">
        <article class="estadistica">
            <h2 class="estadistica_h2">CARRERA DE ESTADISTICA</h2>
        </article>
        <br>
        <form method="post" action="login.php" >
            <table>
                <tr>
                    <td colspan="2" align="center">
                        <label for="">
                            Login
                        </label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="">
                            Cedula De Identidad
                        </label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="txtci">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="">
                            Usuario
                        </label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="txtusuario">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="">
                            Password
                        </label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="password" name="txtpassword">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" name="Ingresar">
                    </td>
                </tr>
            </table>
        </form>
    </section>
    <br>
    <a class="notas_img_a" href="./mostrar.php"><img class="notas_img" src="./IMAGENES/notas.png" style="width:250px;height:300px;"></a>
</body>
</html>